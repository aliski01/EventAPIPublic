package com.example.eventDemo.EventDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
